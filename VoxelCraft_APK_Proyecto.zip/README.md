# VoxelCraft 3D Ultra HD — proyecto APK

## Opción A: GitHub (sin instalar nada)
1. Sube esta carpeta a un repositorio nuevo de GitHub (rama `main`).
2. Pestaña **Actions → Build APK → Run workflow**.
3. Descarga `VoxelCraft-APK` (contiene `app-debug.apk`) e instálalo en tu Android.

## Opción B: Android Studio
1. `bash fetch-libs.sh` (opcional, para jugar sin internet).
2. Abre la carpeta `android/` en Android Studio → **Build → Build APK(s)**.

## Opción C: línea de comandos (JDK 17 + Android SDK)
    bash fetch-libs.sh && cd android && gradle assembleDebug
