package com.voxelcraft.ultrahd;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.*;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage: mundos, skin, nombre
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        web.setWebViewClient(new WebViewClient() {
            // Si hay copias locales en assets/libs (fetch-libs), se usan: el juego funciona sin internet.
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                String f = null, mime = "application/javascript";
                if (u.contains("cdnjs.cloudflare.com/ajax/libs/three.js") || u.contains("unpkg.com/three")) f = "libs/three.min.js";
                else if (u.contains("cdn.tailwindcss.com")) f = "libs/tailwind.js";
                else if (u.contains("fonts.googleapis.com")) { f = "libs/fonts.css"; mime = "text/css"; }
                if (f != null) {
                    try {
                        InputStream in = getAssets().open(f);
                        return new WebResourceResponse(mime, "UTF-8", in);
                    } catch (Exception ignored) { }
                }
                return null;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        // Carga local; los scripts CDN se sirven desde assets/libs si existen
        web.loadUrl("file:///android_asset/index.html");
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){return window.vcBack ? window.vcBack() : false;})()", v -> {
            if (!"true".equals(v)) moveTaskToBack(true);
        });
    }
}
