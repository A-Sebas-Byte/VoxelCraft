#!/usr/bin/env bash
# Descarga las librerías del juego para que el APK funcione 100% sin internet.
set -e
D="$(dirname "$0")/android/app/src/main/assets/libs"; mkdir -p "$D"
curl -L -o "$D/three.min.js"  https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
curl -L -o "$D/tailwind.js"   https://cdn.tailwindcss.com
echo "/* sin fuentes web: se usan las del sistema */" > "$D/fonts.css"
echo "Listo: librerías guardadas en $D"
